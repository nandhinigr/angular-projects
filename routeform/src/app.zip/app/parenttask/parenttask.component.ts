import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parenttask',
  templateUrl: './parenttask.component.html',
  styleUrls: ['./parenttask.component.css']
})
export class ParenttaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
