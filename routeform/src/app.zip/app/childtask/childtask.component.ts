import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childtask',
  templateUrl: './childtask.component.html',
  styleUrls: ['./childtask.component.css']
})
export class ChildtaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
