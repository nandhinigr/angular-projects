export interface IUser {
    id: Number;
    name: String;
    movies: Number;
}